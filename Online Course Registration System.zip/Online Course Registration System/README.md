# Student Registration System
**PengwinTech Solutions — Java Full Stack Project**

A complete Spring Boot + React + MySQL application implementing student registration,
course management, enrollments, JWT authentication, and an admin dashboard.

---

## 1. Tech Stack

| Layer | Technology |
|---|---|
| Backend | Java 17, Spring Boot 3.3, Spring MVC, Spring Data JPA, Spring Security, Hibernate, Maven |
| Frontend | React 18, React Router, Axios, Bootstrap 5, Recharts |
| Database | MySQL 8 |
| Auth | JWT (jjwt), BCrypt password hashing |
| Docs | Swagger / OpenAPI (springdoc) |
| Extras | iText (PDF export), Apache POI (Excel export), Spring Mail |

---

## 2. Architecture (MVC + Layered)

```
Browser (React)
   │  axios + JWT in Authorization header
   ▼
Controller layer   → REST endpoints, @Valid request binding, @PreAuthorize checks
   ▼
Service layer      → business rules, transactions (@Transactional)
   ▼
Repository layer   → Spring Data JPA interfaces (no SQL written by hand)
   ▼
Entity layer        → JPA-mapped tables (Hibernate generates the SQL)
   ▼
MySQL
```

Every layer only talks to the layer directly below it — controllers never touch
repositories directly, services never format HTTP responses. This is what "Follow MVC
Architecture" / "Use Repository Pattern" / "Use DTO Pattern" mean in practice.

### Package structure (`backend/src/main/java/com/pengwintech/srs`)
- `entity/` — JPA entities: `User`, `Student`, `Course`, `Enrollment`, `Role`
- `dto/` — request/response shapes exposed over REST (never expose entities directly)
- `repository/` — `JpaRepository` interfaces (CRUD + custom queries)
- `service/` + `service/impl/` — interfaces and business-logic implementations
- `controller/` — `@RestController` REST endpoints
- `security/` — `JwtUtil`, `JwtAuthFilter`, `UserDetailsServiceImpl`
- `config/` — `SecurityConfig`, `SwaggerConfig`, `DataSeeder`
- `exception/` — custom exceptions + `GlobalExceptionHandler`

---

## 3. Key annotations explained

| Annotation | Purpose |
|---|---|
| `@SpringBootApplication` | Combines `@Configuration` + `@EnableAutoConfiguration` + `@ComponentScan` — the app's entry point |
| `@Entity` / `@Table` | Marks a class as a JPA-managed database table |
| `@Id` / `@GeneratedValue` | Primary key, auto-incremented by MySQL |
| `@OneToMany` / `@ManyToOne` / `@OneToOne` | JPA relationship mappings (see §4) |
| `@RestController` | `@Controller` + `@ResponseBody` — every return value is serialized to JSON |
| `@RequestMapping`, `@GetMapping`, etc. | Maps HTTP verbs + paths to controller methods |
| `@Valid` | Triggers Bean Validation (`@NotBlank`, `@Email`, `@Size`) on the incoming request body |
| `@Service` | Marks a class as a business-logic bean |
| `@Repository` (implicit via `JpaRepository`) | Marks the data-access layer; Spring Data generates the implementation |
| `@Transactional` | Wraps a method in a DB transaction — rolls back all changes on any runtime exception |
| `@RequiredArgsConstructor` (Lombok) | Generates a constructor for all `final` fields = constructor injection with zero boilerplate |
| `@Data`, `@Builder` (Lombok) | Generates getters/setters/toString/equals + a fluent builder |
| `@PreAuthorize("hasRole('ADMIN')")` | Method-level authorization check, evaluated before the method runs |
| `@RestControllerAdvice` | Centralizes exception → HTTP response mapping across all controllers |

---

## 4. JPA relationships (why each one is used)

- **`Student` ⇄ `Enrollment`: `@OneToMany`/`@ManyToOne`** — one student can enroll in many courses.
- **`Course` ⇄ `Enrollment`: `@OneToMany`/`@ManyToOne`** — one course can have many students enrolled.
  `Enrollment` is the resolved join entity between them, because it needs its own columns
  (`enrollmentDate`, `status`) that a plain `@ManyToMany` join table can't hold cleanly.
- **`Student` ⇄ `User`: `@OneToOne`** — a student profile is optionally linked to exactly one login account.

---

## 5. REST API Reference

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create a STUDENT account, returns JWT |
| POST | `/api/auth/login` | Public | Authenticate, returns JWT |
| POST | `/api/auth/logout` | Authenticated | Client discards token (stateless) |
| PUT | `/api/auth/change-password` | Authenticated | Change own password |
| POST | `/api/auth/forgot-password` | Public | Trigger reset flow (stub — wire up `EmailService`) |
| GET | `/api/students?page&size&sortBy&keyword` | Authenticated | Paginated/sortable/searchable list |
| GET | `/api/students/{id}` | Authenticated | Get one student |
| POST | `/api/students` | ADMIN | Create student |
| PUT | `/api/students/{id}` | ADMIN | Update student |
| DELETE | `/api/students/{id}` | ADMIN | Delete student |
| POST | `/api/students/{id}/photo` | ADMIN | Upload student photo (multipart) |
| GET | `/api/courses` | Authenticated | List courses |
| POST/PUT/DELETE | `/api/courses/**` | ADMIN | Manage courses |
| POST | `/api/enrollments` | Authenticated | Enroll a student in a course |
| GET | `/api/enrollments/student/{id}` | Authenticated | View a student's registered courses |
| PUT | `/api/enrollments/{id}/drop` | Authenticated | Drop a course |
| GET | `/api/dashboard/stats` | ADMIN | Dashboard totals + recent registrations |

Full Postman collection: `postman/Student-Registration-System.postman_collection.json`
(import into Postman — login first, the JWT auto-saves into a collection variable for every other request).

Swagger UI (once running): `http://localhost:8080/swagger-ui.html`

---

## 6. Security model

- Passwords hashed with **BCrypt** (`PasswordEncoder` bean) — never stored or compared in plaintext.
- **JWT** issued on login/register, sent as `Authorization: Bearer <token>` on every subsequent request.
- **`JwtAuthFilter`** (a `OncePerRequestFilter`) reads and validates the token on every request,
  populating Spring Security's `SecurityContext` — no server-side session is kept (`STATELESS`).
- **Role-based access control**: `ADMIN` vs `STUDENT`, enforced both at the URL level
  (`SecurityConfig.securityFilterChain`) and at the method level (`@PreAuthorize`) for defense in depth.
- A default `admin` / `Admin@123` account is seeded on first run (`DataSeeder`) — **change this password
  immediately** in any real deployment.

---

## 7. Database setup (MySQL)

```sql
-- Option A: let Hibernate create it automatically (default — see application.properties,
-- spring.jpa.hibernate.ddl-auto=update). Just create the empty schema:
CREATE DATABASE IF NOT EXISTS srs_db;
```

Option B — run the full script manually (also includes sample seed data):
```bash
mysql -u root -p < database/schema.sql
```

Update `backend/src/main/resources/application.properties` with your own MySQL
username/password before running.

---

## 8. Running locally

### Backend
```bash
cd backend
mvn spring-boot:run
# API available at http://localhost:8080
# Swagger UI at http://localhost:8080/swagger-ui.html
```

### Frontend
```bash
cd frontend
npm install
npm start
# App available at http://localhost:3000
```

Login with the seeded admin (`admin` / `Admin@123`), or register a new STUDENT account
from the UI.

---

## 9. Git / GitHub

```bash
cd student-registration-system
git init
git add .
git commit -m "Initial commit: Student Registration System (PengwinTech Solutions)"
git branch -M main
git remote add origin https://github.com/<your-username>/student-registration-system.git
git push -u origin main
```

Add a `.gitignore` (already included) so `target/`, `node_modules/`, and `.env` files
aren't committed.

---

## 10. Deployment notes

- **Backend**: build a runnable jar with `mvn clean package`, deploy the resulting
  `target/*.jar` to any Java host (Render, Railway, EC2, etc.). Point
  `spring.datasource.url` at a managed MySQL instance and move `app.jwt.secret` and
  DB credentials into environment variables rather than committing them.
- **Frontend**: `npm run build` produces a static `build/` folder — deploy it to
  Vercel, Netlify, or serve it from Nginx. Set `REACT_APP_API_URL` to your deployed
  backend URL at build time.
- Update `app.cors.allowed-origins` in `application.properties` to your deployed
  frontend's domain once it's live.

---

## 11. Request flow (Browser → React → Spring Boot → MySQL → Response)

1. User clicks "Login" in the React `Login` page → `authService.login()` fires an
   Axios `POST /api/auth/login`.
2. Request hits Spring's embedded Tomcat → `JwtAuthFilter` runs first (no token yet on
   login, so it just passes through) → reaches `AuthController.login()`.
3. `@Valid` validates the `LoginRequest` body; the controller delegates to `AuthService`.
4. `AuthServiceImpl` calls Spring Security's `AuthenticationManager`, which uses
   `UserDetailsServiceImpl` to load the `User` from `UserRepository` (a Spring Data JPA
   query translated into SQL by Hibernate) and checks the password with BCrypt.
5. On success, `JwtUtil` signs a new JWT containing the username and expiry.
6. `AuthController` returns a `JwtResponse` as JSON via `ResponseEntity`.
7. React stores the token in `localStorage`; every future Axios request attaches it as
   `Authorization: Bearer <token>` (see `services/api.js` interceptor).
8. For a protected call like `GET /api/students`, `JwtAuthFilter` now validates the
   token, populates the security context, `SecurityConfig`'s rules allow the request
   through, `StudentController` calls `StudentService` → `StudentRepository` → MySQL,
   and the resulting `Page<Student>` entities are mapped to `StudentDTO`s and returned
   as JSON, which React renders in the `Students` table.

---

## 12. What's fully built vs. stubbed

**Fully implemented**: auth (register/login/JWT/change-password), student CRUD +
search + pagination + sorting + photo upload, course CRUD, enrollment (enroll/drop/view),
admin dashboard stats + chart, role-based security, global exception handling, Swagger,
dark mode toggle, modal forms, Postman collection, SQL schema.

**Stubbed / next steps** (present in `pom.xml`/structure but not wired into endpoints yet
— ask and I'll build any of these out next):
- PDF/Excel export endpoints (iText and Apache POI are already dependencies)
- Email notifications (Spring Mail is configured; `forgot-password` just needs the send call)
- Attendance module
- Result management module
- Audit logs
