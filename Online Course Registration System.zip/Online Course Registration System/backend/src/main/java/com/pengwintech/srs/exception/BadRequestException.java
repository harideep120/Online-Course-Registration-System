package com.pengwintech.srs.exception;

/** Generic client-error signal (invalid state transitions, bad credentials, etc.) — mapped to HTTP 400. */
public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {
        super(message);
    }
}
