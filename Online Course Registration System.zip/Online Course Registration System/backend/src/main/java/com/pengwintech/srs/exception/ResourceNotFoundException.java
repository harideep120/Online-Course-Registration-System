package com.pengwintech.srs.exception;

/** Thrown when a lookup by ID (or unique field) finds nothing — mapped to HTTP 404 by GlobalExceptionHandler. */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
