package com.pengwintech.srs.controller;

import com.pengwintech.srs.dto.ApiResponse;
import com.pengwintech.srs.dto.StudentDTO;
import com.pengwintech.srs.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    // GET /api/students?page=0&size=10&sortBy=lastName&keyword=john
    // Supports pagination + sorting + search all in one endpoint, matching the "Search Student" /
    // "Pagination" / "Sorting" UI requirements without needing three separate routes.
    @GetMapping
    public ResponseEntity<Page<StudentDTO>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "studentId") String sortBy,
            @RequestParam(defaultValue = "") String keyword) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        return ResponseEntity.ok(studentService.search(keyword, pageable));
    }

    // GET /api/students/{id}
    @GetMapping("/{id}")
    public ResponseEntity<StudentDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(studentService.getById(id));
    }

    // POST /api/students — ADMIN only (enforced in SecurityConfig; @PreAuthorize gives a second,
    // method-level layer of defense in case the URL-based rule is ever loosened).
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<StudentDTO> create(@Valid @RequestBody StudentDTO dto) {
        StudentDTO created = studentService.create(dto);
        return ResponseEntity.status(201).body(created);
    }

    // PUT /api/students/{id}
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<StudentDTO> update(@PathVariable Long id, @Valid @RequestBody StudentDTO dto) {
        return ResponseEntity.ok(studentService.update(id, dto));
    }

    // DELETE /api/students/{id}
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> delete(@PathVariable Long id) {
        studentService.delete(id);
        return ResponseEntity.ok(new ApiResponse(true, "Student deleted successfully"));
    }

    // POST /api/students/{id}/photo — multipart file upload
    @PostMapping("/{id}/photo")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, String>> uploadPhoto(@PathVariable Long id,
                                                             @RequestParam("file") MultipartFile file) {
        String path = studentService.uploadPhoto(id, file);
        return ResponseEntity.ok(Map.of("photoUrl", path));
    }
}
