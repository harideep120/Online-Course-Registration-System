package com.pengwintech.srs.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Incoming payload for POST /api/auth/login. */
@Data
public class LoginRequest {

    @NotBlank
    private String username;

    @NotBlank
    private String password;
}
