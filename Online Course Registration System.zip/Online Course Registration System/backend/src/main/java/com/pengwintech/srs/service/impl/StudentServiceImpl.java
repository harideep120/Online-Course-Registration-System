package com.pengwintech.srs.service.impl;

import com.pengwintech.srs.dto.StudentDTO;
import com.pengwintech.srs.entity.Student;
import com.pengwintech.srs.exception.BadRequestException;
import com.pengwintech.srs.exception.DuplicateResourceException;
import com.pengwintech.srs.exception.ResourceNotFoundException;
import com.pengwintech.srs.repository.StudentRepository;
import com.pengwintech.srs.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    @Value("${app.upload.dir}")
    private String uploadDir;

    @Override
    @Transactional
    public StudentDTO create(StudentDTO dto) {
        if (studentRepository.existsByRollNumber(dto.getRollNumber())) {
            throw new DuplicateResourceException("Roll number already exists: " + dto.getRollNumber());
        }
        if (studentRepository.existsByEmail(dto.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + dto.getEmail());
        }

        Student student = toEntity(dto);
        student.setStudentId(null); // ensure INSERT, not UPDATE, even if a stale id was sent
        return toDto(studentRepository.save(student));
    }

    @Override
    @Transactional
    public StudentDTO update(Long id, StudentDTO dto) {
        Student existing = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));

        existing.setFirstName(dto.getFirstName());
        existing.setLastName(dto.getLastName());
        existing.setGender(dto.getGender());
        existing.setDob(dto.getDob());
        existing.setPhone(dto.getPhone());
        existing.setDepartment(dto.getDepartment());
        existing.setYear(dto.getYear());
        existing.setSemester(dto.getSemester());
        existing.setAddress(dto.getAddress());
        existing.setActive(dto.isActive());
        // rollNumber and email intentionally left immutable after creation in this base version;
        // expose a dedicated endpoint later if editing them needs to be supported.

        return toDto(studentRepository.save(existing));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Student not found with id: " + id);
        }
        studentRepository.deleteById(id);
    }

    @Override
    public StudentDTO getById(Long id) {
        return studentRepository.findById(id)
                .map(this::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
    }

    @Override
    public List<StudentDTO> getAll() {
        return studentRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public Page<StudentDTO> search(String keyword, Pageable pageable) {
        Page<Student> page = (keyword == null || keyword.isBlank())
                ? studentRepository.findAll(pageable)
                : studentRepository.search(keyword, pageable);
        return page.map(this::toDto);
    }

    @Override
    @Transactional
    public String uploadPhoto(Long id, MultipartFile file) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));

        if (file.isEmpty()) {
            throw new BadRequestException("Uploaded file is empty");
        }

        try {
            Path dir = Paths.get(uploadDir);
            Files.createDirectories(dir);

            String extension = "";
            String original = file.getOriginalFilename();
            if (original != null && original.contains(".")) {
                extension = original.substring(original.lastIndexOf('.'));
            }
            String filename = "student_" + id + "_" + UUID.randomUUID() + extension;
            Path target = dir.resolve(filename);
            file.transferTo(target);

            String publicPath = "/uploads/student-photos/" + filename;
            student.setPhoto(publicPath);
            studentRepository.save(student);
            return publicPath;

        } catch (IOException e) {
            throw new BadRequestException("Failed to store photo: " + e.getMessage());
        }
    }

    // ---- mapping helpers (kept simple here; swap for MapStruct in a larger codebase) ----

    private StudentDTO toDto(Student s) {
        return StudentDTO.builder()
                .studentId(s.getStudentId())
                .rollNumber(s.getRollNumber())
                .firstName(s.getFirstName())
                .lastName(s.getLastName())
                .gender(s.getGender())
                .dob(s.getDob())
                .email(s.getEmail())
                .phone(s.getPhone())
                .department(s.getDepartment())
                .year(s.getYear())
                .semester(s.getSemester())
                .address(s.getAddress())
                .photo(s.getPhoto())
                .active(s.isActive())
                .build();
    }

    private Student toEntity(StudentDTO d) {
        return Student.builder()
                .studentId(d.getStudentId())
                .rollNumber(d.getRollNumber())
                .firstName(d.getFirstName())
                .lastName(d.getLastName())
                .gender(d.getGender())
                .dob(d.getDob())
                .email(d.getEmail())
                .phone(d.getPhone())
                .department(d.getDepartment())
                .year(d.getYear())
                .semester(d.getSemester())
                .address(d.getAddress())
                .photo(d.getPhoto())
                .active(true)
                .build();
    }
}
