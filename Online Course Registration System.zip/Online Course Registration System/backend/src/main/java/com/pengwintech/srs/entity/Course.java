package com.pengwintech.srs.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

/**
 * Courses table. One Course can have many Enrollments (@OneToMany, inverse side).
 */
@Entity
@Table(name = "courses")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long courseId;

    @NotBlank
    @Column(nullable = false, unique = true, length = 20)
    private String courseCode;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String courseName;

    private Integer credits;

    @Column(length = 100)
    private String facultyName;

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    @Builder.Default
    private Set<Enrollment> enrollments = new HashSet<>();
}
