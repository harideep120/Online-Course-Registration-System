package com.pengwintech.srs.service;

import com.pengwintech.srs.dto.StudentDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface StudentService {
    StudentDTO create(StudentDTO dto);
    StudentDTO update(Long id, StudentDTO dto);
    void delete(Long id);
    StudentDTO getById(Long id);
    List<StudentDTO> getAll();
    Page<StudentDTO> search(String keyword, Pageable pageable);
    String uploadPhoto(Long id, MultipartFile file);
}
