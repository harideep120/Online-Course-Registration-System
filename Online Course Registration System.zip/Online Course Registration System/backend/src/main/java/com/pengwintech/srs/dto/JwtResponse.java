package com.pengwintech.srs.dto;

import lombok.Data;

/** Response returned after a successful login/register — the token the frontend stores and attaches as a Bearer header. */
@Data
public class JwtResponse {
    private String token;
    private String tokenType = "Bearer";
    private Long userId;
    private String username;
    private String role;

    public JwtResponse(String token, Long userId, String username, String role) {
        this.token = token;
        this.userId = userId;
        this.username = username;
        this.role = role;
    }
}
