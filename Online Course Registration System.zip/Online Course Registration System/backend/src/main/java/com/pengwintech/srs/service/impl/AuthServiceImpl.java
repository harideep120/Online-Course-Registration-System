package com.pengwintech.srs.service.impl;

import com.pengwintech.srs.dto.JwtResponse;
import com.pengwintech.srs.dto.LoginRequest;
import com.pengwintech.srs.dto.RegisterRequest;
import com.pengwintech.srs.entity.Role;
import com.pengwintech.srs.entity.User;
import com.pengwintech.srs.exception.BadRequestException;
import com.pengwintech.srs.exception.DuplicateResourceException;
import com.pengwintech.srs.exception.ResourceNotFoundException;
import com.pengwintech.srs.repository.UserRepository;
import com.pengwintech.srs.security.JwtUtil;
import com.pengwintech.srs.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Service marks this as a Spring-managed business-logic bean (as opposed to @Repository/@Controller).
 * @RequiredArgsConstructor gives us constructor injection for every `final` field below —
 * Spring resolves and injects UserRepository, PasswordEncoder, JwtUtil, AuthenticationManager automatically.
 */
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    @Override
    @Transactional
    public JwtResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already taken: " + request.getUsername());
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already registered: " + request.getEmail());
        }

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword())) // never store plaintext
                .role(Role.STUDENT) // self-registration always creates a STUDENT account; admins are seeded/promoted separately
                .enabled(true)
                .build();

        userRepository.save(user);

        String token = jwtUtil.generateToken(user);
        return new JwtResponse(token, user.getId(), user.getUsername(), user.getRole().name());
    }

    @Override
    public JwtResponse login(LoginRequest request) {
        // Delegates credential checking to Spring Security's AuthenticationManager, which in turn
        // uses our DaoAuthenticationProvider (UserDetailsServiceImpl + BCrypt) — throws
        // BadCredentialsException automatically on mismatch, caught by GlobalExceptionHandler.
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + request.getUsername()));

        String token = jwtUtil.generateToken(user);
        return new JwtResponse(token, user.getId(), user.getUsername(), user.getRole().name());
    }

    @Override
    @Transactional
    public void changePassword(String username, String currentPassword, String newPassword) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));

        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new BadRequestException("Current password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }

    @Override
    public void forgotPassword(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("No account found for email: " + email));

        // In production: generate a short-lived reset token, email a reset link, and verify it
        // in a separate /api/auth/reset-password endpoint. Wired here as a stub so the email
        // service (EmailService, not shown) can be swapped in without touching the controller.
    }
}
