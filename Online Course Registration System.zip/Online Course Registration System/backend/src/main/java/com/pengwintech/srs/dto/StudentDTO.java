package com.pengwintech.srs.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

/**
 * Data Transfer Object for Student create/update/read.
 * Keeps the REST contract independent of the JPA entity — e.g. we deliberately
 * don't expose the linked User or the raw Enrollment set here.
 */
@Data
@Builder
public class StudentDTO {
    private Long studentId;

    @NotBlank
    private String rollNumber;

    @NotBlank
    private String firstName;

    @NotBlank
    private String lastName;

    private String gender;
    private LocalDate dob;

    @Email
    @NotBlank
    private String email;

    private String phone;
    private String department;
    private Integer year;
    private Integer semester;
    private String address;
    private String photo;
    private boolean active;
}
