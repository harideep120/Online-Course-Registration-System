package com.pengwintech.srs.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/** Generic envelope for simple success/error messages returned via ResponseEntity. */
@Data
@Builder
@AllArgsConstructor
public class ApiResponse {
    private boolean success;
    private String message;
}
