package com.pengwintech.srs.service;

import java.util.Map;

public interface DashboardService {
    Map<String, Object> getStats();
}
