package com.pengwintech.srs.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Enrollments table — the resolved many-to-many join between Student and Course.
 * Modeled as its own entity (rather than a plain @ManyToMany) because it carries
 * extra data (enrollmentDate, status) that a pure join table can't hold cleanly.
 *
 * @ManyToOne on both sides: many Enrollments belong to one Student, many belong
 * to one Course. FetchType.LAZY avoids pulling the full Student/Course graph
 * every time an Enrollment is loaded — only fetched when actually accessed.
 */
@Entity
@Table(name = "enrollments", uniqueConstraints = {
        // a student cannot enroll in the same course twice
        @UniqueConstraint(columnNames = {"student_id", "course_id"})
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long enrollmentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @Column(nullable = false)
    private LocalDateTime enrollmentDate;

    @Builder.Default
    @Column(length = 20, nullable = false)
    private String status = "ACTIVE"; // ACTIVE | DROPPED

    @PrePersist
    protected void onCreate() {
        if (enrollmentDate == null) {
            enrollmentDate = LocalDateTime.now();
        }
    }
}
