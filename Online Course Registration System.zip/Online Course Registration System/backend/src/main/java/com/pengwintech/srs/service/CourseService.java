package com.pengwintech.srs.service;

import com.pengwintech.srs.dto.CourseDTO;

import java.util.List;

public interface CourseService {
    CourseDTO create(CourseDTO dto);
    CourseDTO update(Long id, CourseDTO dto);
    void delete(Long id);
    CourseDTO getById(Long id);
    List<CourseDTO> getAll();
}
