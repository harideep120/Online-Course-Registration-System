package com.pengwintech.srs.security;

import com.pengwintech.srs.entity.User;
import com.pengwintech.srs.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Bridges Spring Security's authentication mechanism to our own User table.
 * @RequiredArgsConstructor (Lombok) generates a constructor for all `final` fields —
 * this IS constructor injection, Spring wires UserRepository in automatically.
 */
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByUsername(username)
                .map(User.class::cast)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
    }
}
