package com.pengwintech.srs.entity;

/**
 * Roles recognized by Spring Security for role-based access control (RBAC).
 * Spring Security expects authorities prefixed with "ROLE_", which is handled
 * in the security layer (see JwtAuthFilter / SecurityConfig) rather than here.
 */
public enum Role {
    ADMIN,
    STUDENT
}
