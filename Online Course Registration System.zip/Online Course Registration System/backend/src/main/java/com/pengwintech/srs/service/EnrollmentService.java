package com.pengwintech.srs.service;

import com.pengwintech.srs.dto.EnrollmentDTO;

import java.util.List;

public interface EnrollmentService {
    EnrollmentDTO enroll(Long studentId, Long courseId);
    void drop(Long enrollmentId);
    List<EnrollmentDTO> getByStudent(Long studentId);
    List<EnrollmentDTO> getAll();
}
