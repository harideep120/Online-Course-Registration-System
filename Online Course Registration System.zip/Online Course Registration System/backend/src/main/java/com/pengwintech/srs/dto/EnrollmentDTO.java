package com.pengwintech.srs.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class EnrollmentDTO {
    private Long enrollmentId;

    @NotNull
    private Long studentId;

    @NotNull
    private Long courseId;

    private String studentName;
    private String courseName;
    private LocalDateTime enrollmentDate;
    private String status;
}
