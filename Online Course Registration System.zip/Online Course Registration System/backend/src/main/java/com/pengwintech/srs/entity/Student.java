package com.pengwintech.srs.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * Students table — the core profile record for each enrolled student.
 * One Student can have many Enrollments (@OneToMany), and is linked
 * one-to-one with a login User account.
 */
@Entity
@Table(name = "students")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentId;

    @NotBlank
    @Column(nullable = false, unique = true, length = 30)
    private String rollNumber;

    @NotBlank
    @Column(nullable = false, length = 50)
    private String firstName;

    @NotBlank
    @Column(nullable = false, length = 50)
    private String lastName;

    @Column(length = 10)
    private String gender;

    private LocalDate dob;

    @Email
    @NotBlank
    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(length = 15)
    private String phone;

    @Column(length = 100)
    private String department;

    private Integer year;

    private Integer semester;

    @Column(length = 255)
    private String address;

    @Column(length = 255)
    private String photo; // stored file path/URL, actual bytes live on disk (or S3)

    @Builder.Default
    @Column(nullable = false)
    private boolean active = true;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    // Optional link to the login account (one-to-one). Nullable: a Student
    // record can exist before/without a portal login (e.g. admin bulk import).
    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @JsonIgnore // never serialize the linked User (and its password hash) back in Student responses
    private User user;

    // Inverse side of Enrollment -> Student. mappedBy = owned by Enrollment.student.
    // JsonIgnore prevents infinite recursion when serializing Student -> Enrollments -> Student ...
    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    @Builder.Default
    private Set<Enrollment> enrollments = new HashSet<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
