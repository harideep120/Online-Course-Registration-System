package com.pengwintech.srs.exception;

/** Thrown on unique-constraint violations we catch proactively (e.g. duplicate email/roll number) — mapped to HTTP 409. */
public class DuplicateResourceException extends RuntimeException {
    public DuplicateResourceException(String message) {
        super(message);
    }
}
