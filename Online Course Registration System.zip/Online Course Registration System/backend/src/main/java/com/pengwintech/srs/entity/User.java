package com.pengwintech.srs.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

/**
 * Users table — stores login credentials and role.
 * Implements Spring Security's UserDetails so it can be returned directly
 * by UserDetailsServiceImpl during authentication.
 *
 * @Entity          marks this class as a JPA-managed table.
 * @Table           explicitly names the table (defaults to class name otherwise).
 * @Id / @GeneratedValue  primary key, auto-incremented by the DB (IDENTITY strategy = MySQL AUTO_INCREMENT).
 * @Data (Lombok)   generates getters/setters/toString/equals/hashCode — removes boilerplate.
 * @Builder (Lombok) generates a fluent builder: User.builder().username(...).build().
 */
@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(columnNames = "username"),
        @UniqueConstraint(columnNames = "email")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Email
    @NotBlank
    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @NotBlank
    @Column(nullable = false)
    private String password; // BCrypt-hashed, never stored in plain text

    @Enumerated(EnumType.STRING) // stores "ADMIN"/"STUDENT" text in DB instead of ordinal ints — safer against reordering
    @Column(nullable = false, length = 20)
    private Role role;

    @Builder.Default
    @Column(nullable = false)
    private boolean enabled = true;

    // ---- UserDetails contract (used by Spring Security) ----

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    @Override
    public boolean isAccountNonExpired() { return true; }

    @Override
    public boolean isAccountNonLocked() { return true; }

    @Override
    public boolean isCredentialsNonExpired() { return true; }

    @Override
    public boolean isEnabled() { return enabled; }
}
