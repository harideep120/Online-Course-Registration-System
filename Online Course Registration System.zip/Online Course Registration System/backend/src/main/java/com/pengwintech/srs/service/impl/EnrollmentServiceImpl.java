package com.pengwintech.srs.service.impl;

import com.pengwintech.srs.dto.EnrollmentDTO;
import com.pengwintech.srs.entity.Course;
import com.pengwintech.srs.entity.Enrollment;
import com.pengwintech.srs.entity.Student;
import com.pengwintech.srs.exception.BadRequestException;
import com.pengwintech.srs.exception.ResourceNotFoundException;
import com.pengwintech.srs.repository.CourseRepository;
import com.pengwintech.srs.repository.EnrollmentRepository;
import com.pengwintech.srs.repository.StudentRepository;
import com.pengwintech.srs.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    @Override
    @Transactional
    public EnrollmentDTO enroll(Long studentId, Long courseId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentId));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + courseId));

        enrollmentRepository.findByStudent_StudentIdAndCourse_CourseId(studentId, courseId)
                .ifPresent(e -> {
                    throw new BadRequestException("Student is already enrolled in this course");
                });

        Enrollment enrollment = Enrollment.builder()
                .student(student)
                .course(course)
                .enrollmentDate(LocalDateTime.now())
                .status("ACTIVE")
                .build();

        return toDto(enrollmentRepository.save(enrollment));
    }

    @Override
    @Transactional
    public void drop(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found with id: " + enrollmentId));
        enrollment.setStatus("DROPPED");
        enrollmentRepository.save(enrollment);
    }

    @Override
    public List<EnrollmentDTO> getByStudent(Long studentId) {
        return enrollmentRepository.findByStudent_StudentId(studentId)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public List<EnrollmentDTO> getAll() {
        return enrollmentRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    private EnrollmentDTO toDto(Enrollment e) {
        return EnrollmentDTO.builder()
                .enrollmentId(e.getEnrollmentId())
                .studentId(e.getStudent().getStudentId())
                .courseId(e.getCourse().getCourseId())
                .studentName(e.getStudent().getFirstName() + " " + e.getStudent().getLastName())
                .courseName(e.getCourse().getCourseName())
                .enrollmentDate(e.getEnrollmentDate())
                .status(e.getStatus())
                .build();
    }
}
