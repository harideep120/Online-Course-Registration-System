package com.pengwintech.srs.service.impl;

import com.pengwintech.srs.dto.CourseDTO;
import com.pengwintech.srs.entity.Course;
import com.pengwintech.srs.exception.DuplicateResourceException;
import com.pengwintech.srs.exception.ResourceNotFoundException;
import com.pengwintech.srs.repository.CourseRepository;
import com.pengwintech.srs.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;

    @Override
    @Transactional
    public CourseDTO create(CourseDTO dto) {
        if (courseRepository.existsByCourseCode(dto.getCourseCode())) {
            throw new DuplicateResourceException("Course code already exists: " + dto.getCourseCode());
        }
        Course course = Course.builder()
                .courseCode(dto.getCourseCode())
                .courseName(dto.getCourseName())
                .credits(dto.getCredits())
                .facultyName(dto.getFacultyName())
                .build();
        return toDto(courseRepository.save(course));
    }

    @Override
    @Transactional
    public CourseDTO update(Long id, CourseDTO dto) {
        Course existing = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
        existing.setCourseName(dto.getCourseName());
        existing.setCredits(dto.getCredits());
        existing.setFacultyName(dto.getFacultyName());
        return toDto(courseRepository.save(existing));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!courseRepository.existsById(id)) {
            throw new ResourceNotFoundException("Course not found with id: " + id);
        }
        courseRepository.deleteById(id);
    }

    @Override
    public CourseDTO getById(Long id) {
        return courseRepository.findById(id)
                .map(this::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
    }

    @Override
    public List<CourseDTO> getAll() {
        return courseRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    private CourseDTO toDto(Course c) {
        return CourseDTO.builder()
                .courseId(c.getCourseId())
                .courseCode(c.getCourseCode())
                .courseName(c.getCourseName())
                .credits(c.getCredits())
                .facultyName(c.getFacultyName())
                .build();
    }
}
