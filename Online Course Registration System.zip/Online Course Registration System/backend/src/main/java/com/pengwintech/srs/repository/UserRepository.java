package com.pengwintech.srs.repository;

import com.pengwintech.srs.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repository Pattern: extending JpaRepository gives us CRUD + pagination + sorting
 * for free (findAll, findById, save, deleteById, ...) with zero implementation code —
 * Spring Data JPA generates the implementation at runtime from the method signature.
 */
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
