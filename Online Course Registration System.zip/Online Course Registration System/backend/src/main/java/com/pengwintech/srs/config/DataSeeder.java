package com.pengwintech.srs.config;

import com.pengwintech.srs.entity.Role;
import com.pengwintech.srs.entity.User;
import com.pengwintech.srs.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * CommandLineRunner beans run once, automatically, right after the Spring context starts up.
 * Used here to guarantee an ADMIN account exists on a fresh database — self-registration
 * (see AuthServiceImpl.register) only ever creates STUDENT accounts, so without this seeder
 * there'd be no way to reach any admin-only endpoint on day one.
 *
 * Default login: admin / Admin@123  — change the password immediately in a real deployment.
 */
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.existsByUsername("admin")) {
            return;
        }

        User admin = User.builder()
                .username("admin")
                .email("admin@pengwintech.local")
                .password(passwordEncoder.encode("Admin@123"))
                .role(Role.ADMIN)
                .enabled(true)
                .build();

        userRepository.save(admin);
        System.out.println(">>> Seeded default admin account (username: admin / password: Admin@123)");
    }
}
