package com.pengwintech.srs.service;

import com.pengwintech.srs.dto.JwtResponse;
import com.pengwintech.srs.dto.LoginRequest;
import com.pengwintech.srs.dto.RegisterRequest;

public interface AuthService {
    JwtResponse register(RegisterRequest request);
    JwtResponse login(LoginRequest request);
    void changePassword(String username, String currentPassword, String newPassword);
    void forgotPassword(String email);
}
