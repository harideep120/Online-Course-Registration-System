package com.pengwintech.srs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @SpringBootApplication is a convenience annotation combining:
 *   @Configuration     - this class can define Spring beans
 *   @EnableAutoConfiguration - Spring Boot auto-configures beans based on classpath deps (e.g. sees
 *                              spring-boot-starter-web -> auto-configures an embedded Tomcat + DispatcherServlet)
 *   @ComponentScan      - scans this package and subpackages for @Component/@Service/@Repository/@Controller
 */
@SpringBootApplication
public class StudentRegistrationSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentRegistrationSystemApplication.class, args);
    }
}
