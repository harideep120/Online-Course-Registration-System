package com.pengwintech.srs.controller;

import com.pengwintech.srs.dto.ApiResponse;
import com.pengwintech.srs.dto.EnrollmentDTO;
import com.pengwintech.srs.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/enrollments")
@RequiredArgsConstructor
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    // POST /api/enrollments  { "studentId": 1, "courseId": 3 }
    @PostMapping
    public ResponseEntity<EnrollmentDTO> enroll(@RequestBody Map<String, Long> body) {
        Long studentId = body.get("studentId");
        Long courseId = body.get("courseId");
        return ResponseEntity.status(201).body(enrollmentService.enroll(studentId, courseId));
    }

    // GET /api/enrollments — all enrollments (admin view)
    @GetMapping
    public ResponseEntity<List<EnrollmentDTO>> getAll() {
        return ResponseEntity.ok(enrollmentService.getAll());
    }

    // GET /api/enrollments/student/{studentId} — "View Registered Courses"
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<EnrollmentDTO>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(enrollmentService.getByStudent(studentId));
    }

    // PUT /api/enrollments/{id}/drop — "Drop Course"
    @PutMapping("/{id}/drop")
    public ResponseEntity<ApiResponse> drop(@PathVariable Long id) {
        enrollmentService.drop(id);
        return ResponseEntity.ok(new ApiResponse(true, "Course dropped successfully"));
    }
}
