package com.pengwintech.srs.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseDTO {
    private Long courseId;

    @NotBlank
    private String courseCode;

    @NotBlank
    private String courseName;

    private Integer credits;
    private String facultyName;
}
