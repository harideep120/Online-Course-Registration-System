-- =====================================================
-- Student Registration System - Database Schema
-- Run this in MySQL Workbench, or let Hibernate auto-create it
-- (spring.jpa.hibernate.ddl-auto=update already does this for you on first run).
-- This script is provided for manual setup / review / grading purposes.
-- =====================================================

CREATE DATABASE IF NOT EXISTS srs_db;
USE srs_db;

-- ---------------------------------------------------
-- USERS: login accounts (ADMIN / STUDENT)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,      -- BCrypt hash, ~60 chars
    role VARCHAR(20) NOT NULL,           -- 'ADMIN' or 'STUDENT'
    enabled BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------------------------------------------------
-- STUDENTS: profile records
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    student_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    roll_number VARCHAR(30) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    gender VARCHAR(10),
    dob DATE,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15),
    department VARCHAR(100),
    year INT,
    semester INT,
    address VARCHAR(255),
    photo VARCHAR(255),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME,
    updated_at DATETIME,
    user_id BIGINT,
    CONSTRAINT fk_student_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ---------------------------------------------------
-- COURSES
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS courses (
    course_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL UNIQUE,
    course_name VARCHAR(100) NOT NULL,
    credits INT,
    faculty_name VARCHAR(100)
);

-- ---------------------------------------------------
-- ENROLLMENTS: resolved many-to-many between students and courses
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS enrollments (
    enrollment_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    enrollment_date DATETIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',  -- ACTIVE | DROPPED
    CONSTRAINT fk_enrollment_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_enrollment_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    CONSTRAINT uq_student_course UNIQUE (student_id, course_id)
);

-- ---------------------------------------------------
-- Sample seed data (optional — comment out if not needed)
-- ---------------------------------------------------
INSERT INTO courses (course_code, course_name, credits, faculty_name) VALUES
('CS101', 'Introduction to Programming', 4, 'Dr. Rao'),
('CS201', 'Data Structures', 4, 'Dr. Sharma'),
('CS301', 'Database Management Systems', 3, 'Dr. Iyer'),
('CS401', 'Computer Networks', 3, 'Dr. Nair');

INSERT INTO students (roll_number, first_name, last_name, gender, dob, email, phone, department, year, semester, address, active, created_at, updated_at) VALUES
('21CS001', 'Aarav', 'Kumar', 'Male', '2003-05-14', 'aarav.kumar@example.com', '9876543210', 'Computer Science', 3, 5, 'Hyderabad, Telangana', TRUE, NOW(), NOW()),
('21CS002', 'Diya', 'Reddy', 'Female', '2003-08-21', 'diya.reddy@example.com', '9876543211', 'Computer Science', 3, 5, 'Hyderabad, Telangana', TRUE, NOW(), NOW());
