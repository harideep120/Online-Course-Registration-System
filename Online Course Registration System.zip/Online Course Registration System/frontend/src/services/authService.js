import api from "./api";

const authService = {
  async login(username, password) {
    const { data } = await api.post("/auth/login", { username, password });
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify({ userId: data.userId, username: data.username, role: data.role }));
    return data;
  },

  async register(payload) {
    const { data } = await api.post("/auth/register", payload);
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify({ userId: data.userId, username: data.username, role: data.role }));
    return data;
  },

  logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  },

  getCurrentUser() {
    const raw = localStorage.getItem("user");
    return raw ? JSON.parse(raw) : null;
  },

  changePassword(currentPassword, newPassword) {
    return api.put("/auth/change-password", { currentPassword, newPassword });
  },
};

export default authService;
