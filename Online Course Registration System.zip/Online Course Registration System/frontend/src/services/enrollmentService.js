import api from "./api";

const enrollmentService = {
  enroll: (studentId, courseId) => api.post("/enrollments", { studentId, courseId }),
  getByStudent: (studentId) => api.get(`/enrollments/student/${studentId}`),
  getAll: () => api.get("/enrollments"),
  drop: (enrollmentId) => api.put(`/enrollments/${enrollmentId}/drop`),
};

export default enrollmentService;
