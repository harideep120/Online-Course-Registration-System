import api from "./api";

const studentService = {
  getAll(page = 0, size = 10, sortBy = "studentId", keyword = "") {
    return api.get("/students", { params: { page, size, sortBy, keyword } });
  },
  getById(id) {
    return api.get(`/students/${id}`);
  },
  create(student) {
    return api.post("/students", student);
  },
  update(id, student) {
    return api.put(`/students/${id}`, student);
  },
  delete(id) {
    return api.delete(`/students/${id}`);
  },
  uploadPhoto(id, file) {
    const formData = new FormData();
    formData.append("file", file);
    return api.post(`/students/${id}/photo`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },
};

export default studentService;
