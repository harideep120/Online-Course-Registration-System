import React, { createContext, useContext, useState } from "react";
import authService from "../services/authService";

// React Context lets any component in the tree read/update auth state without
// prop-drilling `user` and `login`/`logout` down through every layer manually.
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(authService.getCurrentUser());

  const login = async (username, password) => {
    const data = await authService.login(username, password);
    setUser({ userId: data.userId, username: data.username, role: data.role });
    return data;
  };

  const register = async (payload) => {
    const data = await authService.register(payload);
    setUser({ userId: data.userId, username: data.username, role: data.role });
    return data;
  };

  const logout = () => {
    authService.logout();
    setUser(null);
  };

  const isAdmin = user?.role === "ADMIN";

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook: components call useAuth() instead of useContext(AuthContext) directly.
export function useAuth() {
  return useContext(AuthContext);
}
