import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// Route guard: redirects to /login if there's no authenticated user,
// and optionally enforces an ADMIN-only route (e.g. the Dashboard).
export default function ProtectedRoute({ children, adminOnly = false }) {
  const { user, isAdmin } = useAuth();

  if (!user) {
    return <Navigate to="/login" replace />;
  }
  if (adminOnly && !isAdmin) {
    return <Navigate to="/students" replace />;
  }
  return children;
}
