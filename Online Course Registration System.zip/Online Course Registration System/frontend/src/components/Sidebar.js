import React from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const links = [
  { to: "/dashboard", label: "Dashboard", adminOnly: true },
  { to: "/students", label: "Students", adminOnly: false },
  { to: "/courses", label: "Courses", adminOnly: false },
  { to: "/profile", label: "Profile Settings", adminOnly: false },
];

export default function Sidebar() {
  const { isAdmin } = useAuth();

  return (
    <div className="bg-light border-end vh-100 p-3" style={{ width: 220 }}>
      <ul className="nav nav-pills flex-column gap-1">
        {links
          .filter((l) => !l.adminOnly || isAdmin)
          .map((l) => (
            <li className="nav-item" key={l.to}>
              <NavLink
                to={l.to}
                className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}
              >
                {l.label}
              </NavLink>
            </li>
          ))}
      </ul>
    </div>
  );
}
