import React, { useEffect, useState } from "react";

const emptyForm = {
  rollNumber: "", firstName: "", lastName: "", gender: "", dob: "",
  email: "", phone: "", department: "", year: "", semester: "", address: "",
};

// A reusable "Modal Popup Form" for both Add Student and Edit Student —
// the same component, switched by whether `student` is passed in.
export default function StudentFormModal({ show, student, onClose, onSave }) {
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    setForm(student ? { ...emptyForm, ...student } : emptyForm);
  }, [student, show]);

  if (!show) return null;

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(form);
  };

  return (
    <div className="modal d-block" tabIndex="-1" style={{ background: "rgba(0,0,0,0.5)" }}>
      <div className="modal-dialog modal-lg">
        <div className="modal-content">
          <form onSubmit={handleSubmit}>
            <div className="modal-header">
              <h5 className="modal-title">{student ? "Edit Student" : "Add Student"}</h5>
              <button type="button" className="btn-close" onClick={onClose}></button>
            </div>
            <div className="modal-body row g-3">
              <div className="col-md-6">
                <label className="form-label">Roll Number</label>
                <input name="rollNumber" className="form-control" value={form.rollNumber}
                       onChange={handleChange} disabled={!!student} required />
              </div>
              <div className="col-md-6">
                <label className="form-label">Email</label>
                <input type="email" name="email" className="form-control" value={form.email}
                       onChange={handleChange} disabled={!!student} required />
              </div>
              <div className="col-md-6">
                <label className="form-label">First Name</label>
                <input name="firstName" className="form-control" value={form.firstName}
                       onChange={handleChange} required />
              </div>
              <div className="col-md-6">
                <label className="form-label">Last Name</label>
                <input name="lastName" className="form-control" value={form.lastName}
                       onChange={handleChange} required />
              </div>
              <div className="col-md-4">
                <label className="form-label">Gender</label>
                <select name="gender" className="form-select" value={form.gender} onChange={handleChange}>
                  <option value="">--</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="col-md-4">
                <label className="form-label">Date of Birth</label>
                <input type="date" name="dob" className="form-control" value={form.dob || ""} onChange={handleChange} />
              </div>
              <div className="col-md-4">
                <label className="form-label">Phone</label>
                <input name="phone" className="form-control" value={form.phone || ""} onChange={handleChange} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Department</label>
                <input name="department" className="form-control" value={form.department || ""} onChange={handleChange} />
              </div>
              <div className="col-md-3">
                <label className="form-label">Year</label>
                <input type="number" name="year" className="form-control" value={form.year || ""} onChange={handleChange} />
              </div>
              <div className="col-md-3">
                <label className="form-label">Semester</label>
                <input type="number" name="semester" className="form-control" value={form.semester || ""} onChange={handleChange} />
              </div>
              <div className="col-12">
                <label className="form-label">Address</label>
                <input name="address" className="form-control" value={form.address || ""} onChange={handleChange} />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
