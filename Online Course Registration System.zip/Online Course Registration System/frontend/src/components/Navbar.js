import React from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

// Top navigation bar: brand, current user, dark-mode toggle, logout.
export default function Navbar({ darkMode, setDarkMode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark px-3">
      <span className="navbar-brand fw-bold">Student Registration System</span>
      <div className="ms-auto d-flex align-items-center gap-3">
        <div className="form-check form-switch text-light">
          <input
            className="form-check-input"
            type="checkbox"
            checked={darkMode}
            onChange={() => setDarkMode(!darkMode)}
            id="darkModeSwitch"
          />
          <label className="form-check-label" htmlFor="darkModeSwitch">Dark Mode</label>
        </div>
        {user && (
          <>
            <span className="text-light small">
              {user.username} ({user.role})
            </span>
            <button className="btn btn-sm btn-outline-light" onClick={handleLogout}>
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
}
