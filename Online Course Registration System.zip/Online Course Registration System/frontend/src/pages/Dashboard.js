import React, { useEffect, useState } from "react";
import dashboardService from "../services/dashboardService";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const Card = ({ title, value, color }) => (
  <div className="col-md-3">
    <div className={`card text-white bg-${color} shadow-sm`}>
      <div className="card-body">
        <h6 className="card-title">{title}</h6>
        <h2 className="fw-bold">{value}</h2>
      </div>
    </div>
  </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardService.getStats()
      .then((res) => setStats(res.data))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-4">Loading dashboard...</div>;
  if (!stats) return <div className="p-4">Failed to load dashboard stats.</div>;

  const chartData = [
    { name: "Students", value: stats.totalStudents },
    { name: "Courses", value: stats.totalCourses },
    { name: "Enrollments", value: stats.totalEnrollments },
    { name: "Active", value: stats.activeStudents },
  ];

  return (
    <div className="p-4">
      <h4 className="mb-4">Admin Dashboard</h4>
      <div className="row g-3 mb-4">
        <Card title="Total Students" value={stats.totalStudents} color="primary" />
        <Card title="Total Courses" value={stats.totalCourses} color="success" />
        <Card title="Total Enrollments" value={stats.totalEnrollments} color="warning" />
        <Card title="Active Students" value={stats.activeStudents} color="info" />
      </div>

      <div className="card p-3 mb-4" style={{ height: 320 }}>
        <h6>Overview</h6>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="value" fill="#0d6efd" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="card p-3">
        <h6>Recent Registrations</h6>
        <table className="table table-sm mb-0">
          <thead><tr><th>Roll No</th><th>Name</th><th>Department</th></tr></thead>
          <tbody>
            {(stats.recentRegistrations || []).map((s) => (
              <tr key={s.studentId}>
                <td>{s.rollNumber}</td>
                <td>{s.firstName} {s.lastName}</td>
                <td>{s.department}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
