import React, { useEffect, useState } from "react";
import studentService from "../services/studentService";
import StudentFormModal from "../components/StudentFormModal";
import { useAuth } from "../context/AuthContext";

export default function Students() {
  const { isAdmin } = useAuth();
  const [data, setData] = useState({ content: [], totalPages: 0, number: 0 });
  const [keyword, setKeyword] = useState("");
  const [sortBy, setSortBy] = useState("studentId");
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = (page = 0) => {
    setLoading(true);
    studentService.getAll(page, 10, sortBy, keyword)
      .then((res) => setData(res.data))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(0); /* eslint-disable-next-line */ }, [sortBy]);

  const handleSearch = (e) => {
    e.preventDefault();
    load(0);
  };

  const handleSave = async (form) => {
    if (editing) {
      await studentService.update(editing.studentId, form);
    } else {
      await studentService.create(form);
    }
    setShowModal(false);
    setEditing(null);
    load(data.number);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this student?")) return;
    await studentService.delete(id);
    load(data.number);
  };

  return (
    <div className="p-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4>Students</h4>
        {isAdmin && (
          <button className="btn btn-primary" onClick={() => { setEditing(null); setShowModal(true); }}>
            + Add Student
          </button>
        )}
      </div>

      <form className="d-flex gap-2 mb-3" onSubmit={handleSearch}>
        <input
          className="form-control"
          placeholder="Search by name, roll number, email, department..."
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
        />
        <select className="form-select" style={{ maxWidth: 180 }} value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
          <option value="studentId">Sort: ID</option>
          <option value="firstName">Sort: First Name</option>
          <option value="rollNumber">Sort: Roll No</option>
          <option value="department">Sort: Department</option>
        </select>
        <button className="btn btn-outline-secondary" type="submit">Search</button>
      </form>

      <div className="card">
        <table className="table table-hover mb-0">
          <thead className="table-light">
            <tr>
              <th>Roll No</th><th>Name</th><th>Email</th><th>Department</th>
              <th>Year/Sem</th><th>Status</th>{isAdmin && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-4">Loading...</td></tr>
            ) : data.content.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-4 text-muted">No students found</td></tr>
            ) : (
              data.content.map((s) => (
                <tr key={s.studentId}>
                  <td>{s.rollNumber}</td>
                  <td>{s.firstName} {s.lastName}</td>
                  <td>{s.email}</td>
                  <td>{s.department}</td>
                  <td>{s.year}/{s.semester}</td>
                  <td>
                    <span className={`badge bg-${s.active ? "success" : "secondary"}`}>
                      {s.active ? "Active" : "Inactive"}
                    </span>
                  </td>
                  {isAdmin && (
                    <td>
                      <button className="btn btn-sm btn-outline-primary me-2"
                              onClick={() => { setEditing(s); setShowModal(true); }}>Edit</button>
                      <button className="btn btn-sm btn-outline-danger"
                              onClick={() => handleDelete(s.studentId)}>Delete</button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data.totalPages > 1 && (
        <nav className="mt-3">
          <ul className="pagination">
            {Array.from({ length: data.totalPages }, (_, i) => (
              <li key={i} className={`page-item ${i === data.number ? "active" : ""}`}>
                <button className="page-link" onClick={() => load(i)}>{i + 1}</button>
              </li>
            ))}
          </ul>
        </nav>
      )}

      <StudentFormModal
        show={showModal}
        student={editing}
        onClose={() => { setShowModal(false); setEditing(null); }}
        onSave={handleSave}
      />
    </div>
  );
}
