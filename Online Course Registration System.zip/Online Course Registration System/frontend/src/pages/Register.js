import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const [form, setForm] = useState({ username: "", email: "", password: "", firstName: "", lastName: "" });
  const [error, setError] = useState("");
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await register(form);
      navigate("/students");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    }
  };

  return (
    <div className="d-flex vh-100 align-items-center justify-content-center bg-light">
      <div className="card shadow p-4" style={{ width: 420 }}>
        <h4 className="mb-3 text-center">Create Account</h4>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="row g-2 mb-2">
            <div className="col-6">
              <input name="firstName" placeholder="First name" className="form-control" onChange={handleChange} />
            </div>
            <div className="col-6">
              <input name="lastName" placeholder="Last name" className="form-control" onChange={handleChange} />
            </div>
          </div>
          <div className="mb-2">
            <input name="username" placeholder="Username" className="form-control" onChange={handleChange} required />
          </div>
          <div className="mb-2">
            <input type="email" name="email" placeholder="Email" className="form-control" onChange={handleChange} required />
          </div>
          <div className="mb-3">
            <input type="password" name="password" placeholder="Password (min 6 chars)" className="form-control" onChange={handleChange} required />
          </div>
          <button className="btn btn-primary w-100" type="submit">Register</button>
        </form>
        <div className="text-center mt-3 small">
          <Link to="/login">Already have an account? Sign in</Link>
        </div>
      </div>
    </div>
  );
}
