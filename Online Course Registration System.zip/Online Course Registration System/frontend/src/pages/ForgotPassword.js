import React, { useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post("/auth/forgot-password", { email });
    setMessage("If that email exists, a reset link has been sent.");
  };

  return (
    <div className="d-flex vh-100 align-items-center justify-content-center bg-light">
      <div className="card shadow p-4" style={{ width: 380 }}>
        <h4 className="mb-3 text-center">Forgot Password</h4>
        {message && <div className="alert alert-success py-2">{message}</div>}
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <input type="email" className="form-control" placeholder="Your email" value={email}
                   onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <button className="btn btn-primary w-100" type="submit">Send Reset Link</button>
        </form>
        <div className="text-center mt-3 small">
          <Link to="/login">Back to login</Link>
        </div>
      </div>
    </div>
  );
}
