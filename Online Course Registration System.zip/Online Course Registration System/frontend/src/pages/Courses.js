import React, { useEffect, useState } from "react";
import courseService from "../services/courseService";
import { useAuth } from "../context/AuthContext";

const emptyForm = { courseCode: "", courseName: "", credits: "", facultyName: "" };

export default function Courses() {
  const { isAdmin } = useAuth();
  const [courses, setCourses] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [showForm, setShowForm] = useState(false);

  const load = () => courseService.getAll().then((res) => setCourses(res.data));

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await courseService.create(form);
    setForm(emptyForm);
    setShowForm(false);
    load();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this course?")) return;
    await courseService.delete(id);
    load();
  };

  return (
    <div className="p-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4>Courses</h4>
        {isAdmin && (
          <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
            {showForm ? "Cancel" : "+ Add Course"}
          </button>
        )}
      </div>

      {showForm && (
        <form className="card p-3 mb-3 row g-2" onSubmit={handleSubmit}>
          <div className="col-md-3">
            <input className="form-control" placeholder="Course Code" required
                   value={form.courseCode} onChange={(e) => setForm({ ...form, courseCode: e.target.value })} />
          </div>
          <div className="col-md-4">
            <input className="form-control" placeholder="Course Name" required
                   value={form.courseName} onChange={(e) => setForm({ ...form, courseName: e.target.value })} />
          </div>
          <div className="col-md-2">
            <input type="number" className="form-control" placeholder="Credits"
                   value={form.credits} onChange={(e) => setForm({ ...form, credits: e.target.value })} />
          </div>
          <div className="col-md-3">
            <input className="form-control" placeholder="Faculty Name"
                   value={form.facultyName} onChange={(e) => setForm({ ...form, facultyName: e.target.value })} />
          </div>
          <div className="col-12">
            <button className="btn btn-success" type="submit">Save Course</button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="table table-hover mb-0">
          <thead className="table-light">
            <tr><th>Code</th><th>Name</th><th>Credits</th><th>Faculty</th>{isAdmin && <th>Actions</th>}</tr>
          </thead>
          <tbody>
            {courses.map((c) => (
              <tr key={c.courseId}>
                <td>{c.courseCode}</td>
                <td>{c.courseName}</td>
                <td>{c.credits}</td>
                <td>{c.facultyName}</td>
                {isAdmin && (
                  <td>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(c.courseId)}>Delete</button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
