import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import authService from "../services/authService";

export default function Profile() {
  const { user } = useAuth();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage(""); setError("");
    try {
      await authService.changePassword(currentPassword, newPassword);
      setMessage("Password updated successfully");
      setCurrentPassword(""); setNewPassword("");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to update password");
    }
  };

  return (
    <div className="p-4" style={{ maxWidth: 480 }}>
      <h4 className="mb-3">Profile Settings</h4>
      <div className="card p-3 mb-3">
        <p className="mb-1"><strong>Username:</strong> {user?.username}</p>
        <p className="mb-0"><strong>Role:</strong> {user?.role}</p>
      </div>

      <div className="card p-3">
        <h6>Change Password</h6>
        {message && <div className="alert alert-success py-2">{message}</div>}
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="mb-2">
            <input type="password" className="form-control" placeholder="Current password"
                   value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
          </div>
          <div className="mb-3">
            <input type="password" className="form-control" placeholder="New password"
                   value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
          </div>
          <button className="btn btn-primary" type="submit">Update Password</button>
        </form>
      </div>
    </div>
  );
}
