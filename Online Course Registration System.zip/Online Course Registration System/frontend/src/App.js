import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";

import { AuthProvider, useAuth } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";

import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import Courses from "./pages/Courses";
import Profile from "./pages/Profile";

// Layout wraps every authenticated page with the Navbar + Sidebar shell.
function Layout({ children, darkMode, setDarkMode }) {
  return (
    <div data-bs-theme={darkMode ? "dark" : "light"}>
      <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
      <div className="d-flex">
        <Sidebar />
        <div className="flex-grow-1">{children}</div>
      </div>
    </div>
  );
}

function AppRoutes() {
  const [darkMode, setDarkMode] = useState(false);
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/students" /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/students" /> : <Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      <Route path="/dashboard" element={
        <ProtectedRoute adminOnly>
          <Layout darkMode={darkMode} setDarkMode={setDarkMode}><Dashboard /></Layout>
        </ProtectedRoute>
      } />
      <Route path="/students" element={
        <ProtectedRoute>
          <Layout darkMode={darkMode} setDarkMode={setDarkMode}><Students /></Layout>
        </ProtectedRoute>
      } />
      <Route path="/courses" element={
        <ProtectedRoute>
          <Layout darkMode={darkMode} setDarkMode={setDarkMode}><Courses /></Layout>
        </ProtectedRoute>
      } />
      <Route path="/profile" element={
        <ProtectedRoute>
          <Layout darkMode={darkMode} setDarkMode={setDarkMode}><Profile /></Layout>
        </ProtectedRoute>
      } />

      <Route path="*" element={<Navigate to="/students" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
